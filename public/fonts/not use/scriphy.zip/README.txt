I know another annoying read me file. 
But I want to say thank you for downloading Scriphy!
Scriphy | Free For Personal and Commercial Use

This handwritten font is an excellent choice for books, crafts, greeting cards, invitations, and other projects that need a personal touch.
This font includes a full set of Uppercase and Lowercase Basic Characters, Numerals, and Punctuation. 

If you like this font, don't forget to show your appreciation and tag me on Instagram! @alalockhart
Making fonts is a lot of work and even the tiniest amount of money would be highly appreciated and motivate me to keep creating.
My Paypal e-mail address is: alalockhart@yahoo.com

(It is entirely up to you if you want to leave a donation, and not doing so should by no means ethically stop you from using it)
If there is anything you'd like to ask, please contact me via email alalockh.arts@gmail.com. 

Copyright © 2021 Ala M. Lockhart

-----------------------------------------------

See more designs here: 
https://alalockhart.gumroad.com/

If you need illustrations please visit my portfolio:
https://alalockhart.com

How to Install Fonts on a Mac
1. Installing fonts on a Mac computer is very easy! The first thing you do is find your favorite font and then click on the "Download Now" button:
2. Click on the font file in your downloads bar to unzip it:
3. You then go to your downloads folder and open the folder containing the font and double click the font file:
4. In the window that comes up when you double click the font, you press the "Install Font" button.
5. Thats it! The font is now installed on your computer and will be available to use everywhere.

How to Install Fonts in Windows
1. Once you have your font downloaded (often .ttf or .otf files), right-click it and click Install. That’s it! I know, uneventful.
2. To check if the font is installed, press Windows key+Q then type: fonts then hit Enter on your keyboard.
3. You should see your fonts listed in the Font Control Panel.
4. If you don’t see it and have a ton of them installed, type in its name in the search box to find it.
5. That’s all there is to it. Now you can create stylish and unique documents!

All the best!
Ala